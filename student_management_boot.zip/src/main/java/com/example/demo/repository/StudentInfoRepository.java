package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.StudentInfo;

//<>안에 처음엔 Entity(StudentInfo), 두번째는 Long type
public interface StudentInfoRepository extends JpaRepository<StudentInfo, Long> {

}
