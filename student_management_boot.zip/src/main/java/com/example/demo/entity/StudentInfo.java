package com.example.demo.entity;


import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity; //JPA이기 때문에. 
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity 
@Table(name="student_info") //student_info 테이블이 생성된다. 
public class StudentInfo {
	
	// JPA에서 Pk는 long으로 하게 되어 있음.
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY) // IDENTITY은 자동 증가
	private Long id;
	
	@Column(name = "jumin_no", length=14)
	private String jumin_no;
	
	@Column(length=20)
	private String name;
	
	// length가 0-255 TINYBLOB
	// 255-65535 BLOB
	// 65535-16777215 MEDINUMBLOB
	// 16777215- LONGBLOB
	@Column(length = 100000) // MEDIUMBLOB으로 적용
	private byte[] picture;
	
	@Column(length=15)
	private String picture_content_type;
	
	@Column(length=13)
	private String tel;
	
	private Timestamp created_date;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getJumin_no() {
		return jumin_no;
	}

	public void setJumin_no(String jumin_no) {
		this.jumin_no = jumin_no;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public byte[] getPicture() {
		return picture;
	}

	public void setPicture(byte[] picture) {
		this.picture = picture;
	}

	public String getPicture_content_type() {
		return picture_content_type;
	}

	public void setPicture_content_type(String picture_content_type) {
		this.picture_content_type = picture_content_type;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public Timestamp getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Timestamp created_date) {
		this.created_date = created_date;
	}
	
}
