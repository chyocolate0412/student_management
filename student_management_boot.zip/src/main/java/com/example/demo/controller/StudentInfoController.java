package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.entity.StudentInfo;
import com.example.demo.repository.StudentInfoRepository;

@Controller
public class StudentInfoController {

	@Autowired
	private StudentInfoRepository infoRepository;
	
	@GetMapping("/add")
	public String add() {
		
		infoRepository.save(new StudentInfo());
		return "add";
	}
	
	@PostMapping("/add")
	public String add(@RequestParam("jumin_no") String jumin_no) {
		
		return "add_result";
	}
	
	@GetMapping("/get_all")
	public String get_all(Model model) {
		
		List<StudentInfo> al_studentInfo = infoRepository.findAll();
		
		model.addAttribute("al_studentInfo",al_studentInfo);
		return "get_all";
	}
	
}
